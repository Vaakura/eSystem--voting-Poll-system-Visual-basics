﻿Imports System.Data.OleDb

Public Class Form1
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection


    Private Sub TabPage3_Click(sender As Object, e As EventArgs) Handles TabPage3.Click

    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        TabControl1.SelectTab(0)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TabControl1.SelectTab(2)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ComboBox17.Items.Add("Male")
        ComboBox17.Items.Add("Female")
        ComboBox14.Items.Add("Computer Science")
        ComboBox14.Items.Add("Engineering")
        ComboBox1.Items.Add("Mathethematics")
        ComboBox1.Items.Add("English")
        ComboBox1.Items.Add("Biology")
        ComboBox1.Items.Add("Physical Science")
        ComboBox1.Items.Add("Accounting")
        ComboBox1.Items.Add("Afrikaans")
        ComboBox1.Items.Add("Oshiwambo")
        ComboBox1.Items.Add("Otjiherero")
        ComboBox1.Items.Add("Agriculture")
        ComboBox1.Items.Add("Computer Studies")
        ComboBox1.Items.Add("Development Studies")
        ComboBox9.Items.Add("A")
        ComboBox9.Items.Add("B")
        ComboBox9.Items.Add("C")
        ComboBox9.Items.Add("D")
        ComboBox9.Items.Add("E")
        ComboBox9.Items.Add("F")
        ComboBox9.Items.Add("G")
        ComboBox9.Items.Add("U")
        ComboBox9.Items.Add("L1")
        ComboBox9.Items.Add("L2")
        ComboBox9.Items.Add("L3")
        ComboBox9.Items.Add("L4")
        ComboBox9.Items.Add("L5")
        ComboBox3.Items.Add("IGCSE")
        ComboBox3.Items.Add("HIGCSE")

        ComboBox6.Items.Add("Mathethematics")
        ComboBox6.Items.Add("English")
        ComboBox6.Items.Add("Biology")
        ComboBox6.Items.Add("Physical Science")
        ComboBox6.Items.Add("Accounting")
        ComboBox6.Items.Add("Afrikaans")
        ComboBox6.Items.Add("Oshiwambo")
        ComboBox6.Items.Add("Otjiherero")
        ComboBox6.Items.Add("Agriculture")
        ComboBox6.Items.Add("Computer Studies")
        ComboBox6.Items.Add("Development Studies")
        ComboBox4.Items.Add("A")
        ComboBox4.Items.Add("B")
        ComboBox4.Items.Add("C")
        ComboBox4.Items.Add("D")
        ComboBox4.Items.Add("E")
        ComboBox4.Items.Add("F")
        ComboBox4.Items.Add("G")
        ComboBox4.Items.Add("U")
        ComboBox4.Items.Add("L1")
        ComboBox4.Items.Add("L2")
        ComboBox4.Items.Add("L3")
        ComboBox4.Items.Add("L4")
        ComboBox4.Items.Add("L5")
        ComboBox5.Items.Add("IGCSE")
        ComboBox5.Items.Add("HIGCSE")





        ComboBox10.Items.Add("Mathethematics")
        ComboBox10.Items.Add("English")
        ComboBox10.Items.Add("Biology")
        ComboBox10.Items.Add("Physical Science")
        ComboBox10.Items.Add("Accounting")
        ComboBox10.Items.Add("Afrikaans")
        ComboBox10.Items.Add("Oshiwambo")
        ComboBox10.Items.Add("Otjiherero")
        ComboBox10.Items.Add("Agriculture")
        ComboBox10.Items.Add("Computer Studies")
        ComboBox10.Items.Add("Development Studies")
        ComboBox7.Items.Add("A")
        ComboBox7.Items.Add("B")
        ComboBox7.Items.Add("C")
        ComboBox7.Items.Add("D")
        ComboBox7.Items.Add("E")
        ComboBox7.Items.Add("F")
        ComboBox7.Items.Add("G")
        ComboBox7.Items.Add("U")
        ComboBox7.Items.Add("L1")
        ComboBox7.Items.Add("L2")
        ComboBox7.Items.Add("L3")
        ComboBox7.Items.Add("L4")
        ComboBox7.Items.Add("L5")
        ComboBox8.Items.Add("IGCSE")
        ComboBox8.Items.Add("HIGCSE")




        ComboBox13.Items.Add("Mathethematics")
        ComboBox13.Items.Add("English")
        ComboBox13.Items.Add("Biology")
        ComboBox13.Items.Add("Physical Science")
        ComboBox13.Items.Add("Accounting")
        ComboBox13.Items.Add("Afrikaans")
        ComboBox13.Items.Add("Oshiwambo")
        ComboBox13.Items.Add("Otjiherero")
        ComboBox13.Items.Add("Agriculture")
        ComboBox13.Items.Add("Computer Studies")
        ComboBox13.Items.Add("Development Studies")
        ComboBox11.Items.Add("A")
        ComboBox11.Items.Add("B")
        ComboBox11.Items.Add("C")
        ComboBox11.Items.Add("D")
        ComboBox11.Items.Add("E")
        ComboBox11.Items.Add("F")
        ComboBox11.Items.Add("G")
        ComboBox11.Items.Add("U")
        ComboBox11.Items.Add("L1")
        ComboBox11.Items.Add("L2")
        ComboBox11.Items.Add("L3")
        ComboBox11.Items.Add("L4")
        ComboBox11.Items.Add("L5")
        ComboBox12.Items.Add("IGCSE")
        ComboBox12.Items.Add("HIGCSE")




        ComboBox18.Items.Add("Mathethematics")
        ComboBox18.Items.Add("English")
        ComboBox18.Items.Add("Biology")
        ComboBox18.Items.Add("Physical Science")
        ComboBox18.Items.Add("Accounting")
        ComboBox18.Items.Add("Afrikaans")
        ComboBox18.Items.Add("Oshiwambo")
        ComboBox18.Items.Add("Otjiherero")
        ComboBox18.Items.Add("Agriculture")
        ComboBox18.Items.Add("Computer Studies")
        ComboBox18.Items.Add("Development Studies")
        ComboBox2.Items.Add("A")
        ComboBox2.Items.Add("B")
        ComboBox2.Items.Add("C")
        ComboBox2.Items.Add("D")
        ComboBox2.Items.Add("E")
        ComboBox2.Items.Add("F")
        ComboBox2.Items.Add("G")
        ComboBox2.Items.Add("U")
        ComboBox2.Items.Add("L1")
        ComboBox2.Items.Add("L2")
        ComboBox2.Items.Add("L3")
        ComboBox2.Items.Add("L4")
        ComboBox2.Items.Add("L5")
        ComboBox15.Items.Add("IGCSE")
        ComboBox15.Items.Add("HIGCSE")







        


    End Sub

    Private Sub ComboBox8_SelectedIndexChanged(sender As Object, e As EventArgs)


    End Sub

    Private Sub TabPage2_Click(sender As Object, e As EventArgs) Handles TabPage2.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged



    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs)
        ' ComboBox15.Items.Clear()
        'If ComboBox2.Text = ("Computer Science") Then
        ' ComboBox15.Items.Add("Informatics")
        'ComboBox15.Items.Add("Software")
        ' ComboBox15.Items.Add("Networking")
        'ElseIf ComboBox2.Text = "Engineering" Then
        'ComboBox15.Items.Add("B.TECH (EE)")
        ' ComboBox15.Items.Add("M.TECH (EE)")
        ''Else


        'End If 
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        OpenFileDialog1.Filter = "image file(*.jpg, *.png, *.bmp) |*.jpg; *.png; *.bmp| all files(*.*) | *.*"
        If OpenFileDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            PictureBox2.Image = Image.FromFile(OpenFileDialog1.FileName)

        End If

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If MessageBox.Show(" Do you want to exit?", "eSelection System",
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                       = DialogResult.Yes Then
            Application.Exit()

        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Using conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\corp\Desktop\eSystem\eSystem\bin\Debug\eSystem.accdb'")
            Using cmd = New OleDbCommand()
                conn.Open()
                cmd.Connection = conn
                cmd.CommandText = "INSERT INTO Student(FName,LName,ID,DOB,Email,Gender,Subject1,Level1,Symbol1,Program,Course) " & _
         "Values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Value & "','" & TextBox4.Text & "','" & ComboBox17.Text & "','" & ComboBox1.Text & "','" & ComboBox3.Text & "','" & ComboBox9.Text & "','" & ComboBox14.Text & "','" & ComboBox16.Text & "')"
                'cmd.Parameters.AddWithValue("@p1", lblNo.Text)
                cmd.ExecuteNonQuery()
                MsgBox("You have registered and your Data is being processed..")
                conn.Close()
            End Using
        End Using

   
    End Sub

    Private Sub ComboBox16_SelectedIndexChanged(sender As Object, e As EventArgs)
   
    End Sub

    Private Sub ComboBox14_SelectedIndexChanged(sender As Object, e As EventArgs)
       
    End Sub

    Private Sub ComboBox14_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles ComboBox14.SelectedIndexChanged
        ComboBox16.Items.Clear()
        If ComboBox14.Text = ("Computer Science") Then
            ComboBox16.Items.Add("Informatics")
            ComboBox16.Items.Add("Software")
            ComboBox16.Items.Add("Networking")
        ElseIf ComboBox14.Text = "Engineering" Then
            ComboBox16.Items.Add("B.TECH (EE)")
            ComboBox16.Items.Add("M.TECH (EE)")
        Else

        End If
    End Sub
End Class
